// add new version of fabric here
const Version = ['v1.2'];

export default Version;

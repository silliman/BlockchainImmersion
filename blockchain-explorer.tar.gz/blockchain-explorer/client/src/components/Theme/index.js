import Theme from './Theme';

export default Theme;

import FooterView from './FooterView';

export default FooterView;

import HeaderView from './HeaderView';

export default HeaderView;

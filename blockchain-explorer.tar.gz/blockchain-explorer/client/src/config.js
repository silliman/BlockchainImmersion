/**
 *    SPDX-License-Identifier: Apache-2.0
 */

import config from 'react-global-configuration';

config.set({ api: 'web3' });

export default config;
